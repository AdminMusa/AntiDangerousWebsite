// List of scam websites
const scamWebsites = [
    "4drd.icu", "akcesori.pl", "alias.baby", "alltaggeds.com", "anybootz.com",
    "appelem.net", "armadisplace.net", "awashiga.xyz", "bcpow.com", "blackhole79.com",
    "btem.de", "c21me.com", "clmhca9f.com", "cliniciweb.ro", "cubexgalleria.com",
    "datejealousy.com", "datingboss247.com", "dirtytocket.com", "douxplan.com",
    "empregos24h.net", "enfantsastuces.com", "eternosfuturo.com", "fairyfloss.design",
    "floridaspeedway.com", "fnocs.com", "funnyseonames.com", "g7b3x0.site",
    "getbistro.com", "hardplay.moscow", "highroadsoccer.com", "hotmatrimony.com",
    "icfhf2021.cn", "kushcartel.com", "lcongress.net", "lfk87.top", "motivecreative.com",
    "mylatestupdates.com", "newyear2022.com", "nuevecero.com", "onegoddess.com",
    "otwhimsy.com", "passionscenario.com", "playforstronger.com", "promovideos.net",
    "resetheducation.org", "seekanswers.net", "sipheavystreaming.com", "s7an9p.com",
    "thatyellow.com", "timewise.com", "vitalfreak.com", "volk9io.com", "whatsappaccess.com",
    "whitestormorchestra.com", "wowcraft.xyz", "x12game.com", "xenoproducts.net", "y8v7tt.com",
    "yaywowou.com", "zdnetasia.com", "bgochz.com", "bcxlwm.com", "bwnkfq.com", "c3dft0.com",
    "c9xf7k.com", "d8q5mb.com", "dp6fwq.com", "fmd8mr.com", "gz9vgd.com", "jx2exr.com",
    "kpwyv0.com", "l8nkq9.com", "lxfw0t.com", "pfntbc.com", "pw6a8f.com", "qg5cdq.com",
    "sdkslq.com", "t9xgd2.com", "ub4pdi.com", "vug3zn.com", "wuwwxd.com", "y2sfsc.com",
    "yt2f7t.com", "z7yykx.com", "zqaxft.com",
    "gravematters.us", "9minecraft.net", "vipcopperapp.monster", "6minecraft.net", "7minecraft.net",
    "igetintopc.com", "kingmodapk.com", "apkmodget.com", "wizcase.com", "techspot.com", "aladel.net",
    "bpwhamburgorchardpark.org", "clicnews.com", "dfwdiesel.net", "divineenterprises.net", "gardensrestaurantandcatering.com",
    "ginedis.com", "gncr.org", "hdvideoforums.org", "hihanin.com", "kingfamilyphotoalbum.com", "likaraoke.com",
    "gay.com", "mactep.org", "magic4you.nu", "nacjalneg.info", "pronline.ru", "qsng.cn", "seksburada.net",
    "sportsmansclub.net", "tathli.com", "teamclouds.com", "texaswhitetailfever.com", "xnescat.info"
];

// Get the current domain from the URL and convert it to lowercase
const current_domain = window.location.hostname.toLowerCase();

// Remove the 'www.' part of the domain if present
const normalized_current_domain = current_domain.replace(/^www\./, "");

// Normalize the scam list and ensure they are only domains without protocols or paths
const normalizedScamWebsites = scamWebsites.map(domain => domain.toLowerCase());

// Check if the current domain matches any of the scam websites (case insensitive, ignoring paths and protocols)
const isScam = normalizedScamWebsites.some(domain => normalized_current_domain === domain);

// Block the website if it is in the scam list
if (isScam) {
    document.body.innerHTML = '<h1 style="color: red;">This is a scam website</h1><p style="color: red;">Please avoid this website.</p>';
    document.body.style.backgroundColor = "#000000"; // Corrected color hex format
    console.log("Threat Blocked due to being dangerous or contains some over 18+");
    window.stop(); // Stops the page from loading further
}
